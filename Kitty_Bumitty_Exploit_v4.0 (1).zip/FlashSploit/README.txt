WARNING:
Please do not edit anything in here or the exploit wont work!

Thank you,
Kitty Bumitty Exploit Developers Team
Signed By Owner
Proofing code:
FH291GF83G28FG739GF8HN389B7BG39